<?php
class latihan1 extends CI_Controller
{
    public function index()
    {

    $Nim="19200308";
    $Nama= "Ahmad Daniawan";
    $Jurusan="Sistem Informasi";
    $Alamat="Rawabelong";
    $Hobby="Badminton";

    echo "<h1> BIO DATA </h1>";
    echo"Nim:$Nim<br>";
    echo"Nama:$Nama<br>";
    echo"Jurusan:$Jurusan<br>";
    echo"Alamat:$Alamat<br>";
    echo"Hobby:$Hobby<br>";
}
    }